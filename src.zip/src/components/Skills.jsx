import { motion } from "framer-motion";
import { useEffect, useState } from "react";
import axios from "axios";

import {
	FaJava,
	FaReact,
	FaHtml5,
	FaCss3Alt,
	FaGitAlt
} from "react-icons/fa";

import {
	SiSpringboot,
	SiMysql,
	SiApachekafka,
	SiRedis
} from "react-icons/si";

function Skills() {

	const [skills, setSkills] = useState([]);

	useEffect(() => {

		loadSkills();

	}, []);

	const loadSkills = async () => {

		try {

			const response = await axios.get(
				"http://localhost:8080/skill/list"
			);

			setSkills(response.data);

		} catch (error) {

			console.log(error);

		}
	};

	const getIcon = (skillName) => {

		switch (skillName.toLowerCase()) {

			case "java":
				return <FaJava />;

			case "react":
				return <FaReact />;

			case "spring boot":
				return <SiSpringboot />;

			case "mysql":
				return <SiMysql />;

			case "kafka":
				return <SiApachekafka />;

			case "redis":
				return <SiRedis />;

			case "html":
				return <FaHtml5 />;

			case "css":
				return <FaCss3Alt />;

			case "git":
				return <FaGitAlt />;

			default:
				return <FaJava />;
		}
	};

	return (

		<section className="py-20 mt-12">

			<div className="container-custom">

				<h1 className="text-center text-6xl font-bold mb-24">

					My <span className="text-cyan-400">Skills</span>

				</h1>

				<div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-10">

					{
						skills.map((skill) => (

							<motion.div
								key={skill.id}
								whileHover={{
									y: -10,
									scale: 1.03
								}}
								className="bg-slate-900/70 border border-cyan-500/10 rounded-[35px] p-10 flex flex-col items-center justify-center backdrop-blur-xl shadow-lg hover:shadow-cyan-500/20 duration-300"
							>

								<div className="text-7xl text-cyan-400 mb-6">

									{getIcon(skill.skillName)}

								</div>

								<h2 className="text-2xl font-semibold">

									{skill.skillName}

								</h2>

							</motion.div>

						))
					}

				</div>

			</div>

		</section>

	);
}

export default Skills;