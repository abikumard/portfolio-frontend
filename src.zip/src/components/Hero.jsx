import { motion } from "framer-motion";

function Hero() {

	const downloadResume = () => {

		window.open(
			"http://localhost:8080/resume/download",
			"_blank"
		);
	};

	return (

		<section className="h-screen flex justify-center items-center relative overflow-hidden">

			<div className="absolute left-1/2 -translate-x-1/2 w-96 h-96 bg-cyan-500/20 rounded-full blur-3xl"></div>

			<div className="container-custom text-center z-10">

				<motion.h1
					initial={{ opacity: 0, y: -50 }}
					animate={{ opacity: 1, y: 0 }}
					transition={{ duration: 1 }}
					className="text-6xl md:text-7xl font-bold"
				>

					Hi, I'm
					<span className="text-cyan-400"> Abikumar</span>

				</motion.h1>

				<motion.p
					initial={{ opacity: 0 }}
					animate={{ opacity: 1 }}
					transition={{ delay: 1 }}
					className="mt-6 text-xl text-gray-300"
				>

					Java Full Stack Developer

				</motion.p>

				<motion.div
					initial={{ opacity: 0 }}
					animate={{ opacity: 1 }}
					transition={{ delay: 1.5 }}
					className="mt-10 flex justify-center gap-6 flex-wrap"
				>

					<button
						className="w-[220px] bg-cyan-500 px-8 py-4 rounded-2xl font-semibold hover:scale-105 duration-300 shadow-lg shadow-cyan-500/30"
					>
						View Projects
					</button>

					<button
						onClick={downloadResume}
						className="w-[220px] border border-cyan-400 px-8 py-4 rounded-2xl hover:bg-cyan-500 duration-300 font-semibold"
					>
						Download Resume
					</button>

				</motion.div>

			</div>

		</section>

	);
}

export default Hero;