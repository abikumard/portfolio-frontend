import { motion } from "framer-motion";
import { useEffect, useState } from "react";
import axios from "axios";
import "./Experience.css";

function Experience() {

	const [experienceData, setExperienceData] = useState([]);

	useEffect(() => {

		loadExperience();

	}, []);

	const loadExperience = async () => {

		try {

			const response = await axios.get(
				"http://localhost:8080/experience/list"
			);

			setExperienceData(response.data);

		} catch (error) {

			console.log(error);

		}

	};

	return (

		<section className="experience-section">

			<div className="experience-container">

				<motion.h1
					initial={{ opacity: 0, y: -50 }}
					whileInView={{ opacity: 1, y: 0 }}
					transition={{ duration: 1 }}
					className="experience-title"
				>

					My <span>Experience</span>

				</motion.h1>

				<div className="experience-grid">

					{
						experienceData.map((item) => (

							<motion.div
								key={item.id}
								initial={{ opacity: 0, y: 100 }}
								whileInView={{ opacity: 1, y: 0 }}
								transition={{ duration: 1 }}
								whileHover={{ y: -10 }}
								className="experience-card"
							>

								<div className="experience-top">

									<h2>{item.designation}</h2>

									<p className="company-name">

										{item.company}

									</p>

									<span className="duration">

										{item.duration}

									</span>

								</div>

								<p className="experience-description">

									{item.description}

								</p>

							</motion.div>

						))
					}

				</div>

			</div>

		</section>

	);

}

export default Experience;