import { motion } from "framer-motion";
import { useEffect, useState } from "react";
import axios from "axios";

import img1 from "../assets/project-1.svg";
import img2 from "../assets/project-2.svg";
import img3 from "../assets/project-3.svg";

function Projects() {

	const [projects, setProjects] = useState([]);

	useEffect(() => {

		loadProjects();

	}, []);

	const loadProjects = async () => {

		try {

			const response = await axios.get(
				"http://localhost:8080/project/list"
			);

			setProjects(response.data);

		} catch (error) {

			console.log(error);

		}
	};

	return (

		<section className="py-20">

			<div className="container-custom">

				<h1 className="text-center text-6xl font-bold mb-24">

					My <span className="text-cyan-400">Projects</span>

				</h1>

				<div className="grid md:grid-cols-2 lg:grid-cols-3 gap-12">

					{
						projects.map((project, index) => (

							<motion.div
								key={project.id}
								whileHover={{ y: -10 }}
								className="bg-slate-900/70 rounded-[35px] overflow-hidden border border-cyan-500/10 backdrop-blur-xl shadow-lg hover:shadow-cyan-500/20 duration-300"
							>

								<div className="h-64 overflow-hidden rounded-t-[35px]">

									<img
										src={[img1, img2, img3][index % 3]}
										alt={project.title}
										className="w-full h-full object-cover object-center block"
										loading="lazy"
									/>

								</div>

								<div className="p-8 flex flex-col justify-between min-h-[320px]">

									<div>

										<h2 className="text-3xl font-bold mb-5">

											{project.title}

										</h2>

										<p className="text-gray-300 leading-8 text-lg">

											{project.description}

										</p>

										<p className="mt-6 text-cyan-400 leading-7">

											{project.technologies}

										</p>

									</div>

									<div className="mt-10 flex items-center justify-end gap-10">

										<a
											href={project.liveLink}
											target="_blank"
											rel="noreferrer"
										>

											<button className="relative left-3 bg-cyan-500 px-6 py-3 rounded-xl font-semibold hover:scale-105 duration-300">

												Live Demo

											</button>

										</a>

										<a
											href={project.githubLink}
											target="_blank"
											rel="noreferrer"
										>

											<button className="relative right-3 border border-cyan-400 px-6 py-3 rounded-xl hover:bg-cyan-500 duration-300 font-semibold">

												GitHub

											</button>

										</a>

									</div>

								</div>

							</motion.div>

						))
					}

				</div>

			</div>

		</section>

	);
}

export default Projects;