import { motion } from "framer-motion";

function About() {

	return (

	 <section id="about" className="py-20">

			<div className="container-custom grid lg:grid-cols-2 gap-24 items-center">

				<motion.div
					initial={{ opacity:0, x:-100 }}
					whileInView={{ opacity:1, x:0 }}
					transition={{ duration:1 }}
				>

					<h1 className="text-5xl font-bold mb-8">
						About <span className="text-cyan-400">Me</span>
					</h1>

					<p className="text-gray-300 text-lg leading-9">

						I am <span className="text-cyan-400 font-semibold">Abikumar</span>,
						a passionate Java Full Stack Developer from Chennai.

						I completed my B.Tech Information Technology degree at
						Kings Engineering College.

						I specialize in building responsive and scalable web applications
						using React.js, Spring Boot, MySQL, Redis, and Kafka.

						I enjoy developing enterprise-level applications with
						clean architecture and modern UI design.

					</p>

				</motion.div>

				<motion.div
					initial={{ opacity:0, x:100 }}
					whileInView={{ opacity:1, x:0 }}
					transition={{ duration:1 }}
					className="bg-slate-900/80 border border-cyan-500/10 p-12 rounded-[40px] shadow-2xl backdrop-blur-xl"
				>

					<div className="space-y-6 text-lg">

						<div>
							<span className="text-cyan-400 font-semibold">
								Name :
							</span>
							<span className="ml-3 text-gray-300">
								Abikumar
							</span>
						</div>

						<div>
							<span className="text-cyan-400 font-semibold">
								Role :
							</span>
							<span className="ml-3 text-gray-300">
								Java Full Stack Developer
							</span>
						</div>

						<div>
							<span className="text-cyan-400 font-semibold">
								Location :
							</span>
							<span className="ml-3 text-gray-300">
								Chennai
							</span>
						</div>

						<div>
							<span className="text-cyan-400 font-semibold">
								Email :
							</span>
							<span className="ml-3 text-gray-300">
								abikumarr003@gmail.com
							</span>
						</div>

					</div>

				</motion.div>

			</div>

		</section>

	)
}

export default About

