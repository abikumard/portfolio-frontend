import { motion } from "framer-motion";
import { useState } from "react";
import axios from "axios";

function HRForm() {

  const [formData, setFormData] = useState({
    hrName: "",
    companyName: "",
    email: "",
    phone: "",
    requirementDetails: ""
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async () => {

    try {

      const response = await axios.post(
        "http://localhost:8080/hr/save",
        formData
      );

      alert(response.data);

      setFormData({
        hrName: "",
        companyName: "",
        email: "",
        phone: "",
        requirementDetails: ""
      });

    } catch (error) {

      console.error(error);

      alert("Failed To Save Details");
    }
  };

  return (

    <section className="py-32 px-6 flex items-center justify-center relative overflow-hidden">

      <div className="absolute w-[400px] h-[400px] bg-cyan-500/10 blur-3xl rounded-full"></div>

      <motion.div
        initial={{ opacity:0, y:80 }}
        whileInView={{ opacity:1, y:0 }}
        transition={{ duration:1 }}
        className="w-full max-w-5xl bg-slate-900/70 border border-cyan-500/10 rounded-[40px] p-12 md:p-16 backdrop-blur-2xl shadow-2xl shadow-cyan-500/10 relative z-10"
      >

        <div className="text-center mb-14">

          <h1 className="text-5xl md:text-6xl font-bold leading-tight">

            Interested To
            <span className="text-cyan-400"> Hire Me?</span>

          </h1>

        </div>

        <div className="grid md:grid-cols-2 gap-8">

          <div className="flex flex-col gap-3 ">

            <label className="text-gray-300 text-lg ">
              HR Name
            </label>

            <input
              type="text"
              name="hrName"
              value={formData.hrName}
              onChange={handleChange}
              placeholder="Enter HR Name"
               className="bg-slate-800/80 border border-cyan-500/10 px-6 py-5 rounded-2xl outline-none"
            />

          </div>

          <div className="flex flex-col gap-3">

            <label className="text-gray-300 text-lg">
              Company Name
            </label>

            <input
              type="text"
              name="companyName"
              value={formData.companyName}
              onChange={handleChange}
              placeholder="Enter Company Name"
              className="bg-slate-800/80 border border-cyan-500/10 px-6 py-5 rounded-2xl outline-none"
            />

          </div>

          <div className="flex flex-col gap-3">

            <label className="text-gray-300 text-lg">
              Email Address
            </label>

            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="Enter Email Address"
              className="bg-slate-800/80 border border-cyan-500/10 px-6 py-5 rounded-2xl outline-none"
            />

          </div>

          <div className="flex flex-col gap-3">

            <label className="text-gray-300 text-lg">
              Phone Number
            </label>

            <input
              type="text"
              name="phone"
              value={formData.phone}
              onChange={handleChange}
              placeholder="Enter Phone Number"
              className="bg-slate-800/80 border border-cyan-500/10 px-6 py-5 rounded-2xl outline-none"
            />

          </div>

        </div>

        <div className="mt-8 flex flex-col gap-3">

          <label className="text-gray-300 text-lg">
            Requirement Details
          </label>

          <textarea
            rows="6"
            name="requirementDetails"
            value={formData.requirementDetails}
            onChange={handleChange}
            placeholder="Describe your requirement..."
            className="w-full bg-slate-800/80 border border-cyan-500/10 px-6 py-5 rounded-2xl outline-none resize-none"
          ></textarea>

        </div>

        <button
          onClick={handleSubmit}
          className="w-full mt-10 bg-cyan-500 hover:bg-cyan-400 py-5 rounded-2xl text-xl font-semibold"
        >
          Submit Details
        </button>

      </motion.div>

    </section>

  )
}

export default HRForm