function Navbar() {

	return (

		<nav className="fixed top-0 w-full z-50 bg-[#020617]/80 backdrop-blur-xl border-b border-cyan-500/10">

			<div className="container-custom flex justify-between items-center py-5">

				<h1 className="text-4xl font-extrabold tracking-wide text-cyan-400">

					Abikumar

				</h1>

				<ul className="hidden md:flex gap-12 text-lg font-medium text-gray-300">

					<li className="hover:text-cyan-400 duration-300 cursor-pointer">
						Home
					</li>

					<li className="hover:text-cyan-400 duration-300 cursor-pointer">
						About
					</li>

					<li className="hover:text-cyan-400 duration-300 cursor-pointer">
						Skills
					</li>

					<li className="hover:text-cyan-400 duration-300 cursor-pointer">
						Projects
					</li>

					<li className="hover:text-cyan-400 duration-300 cursor-pointer">
						Contact
					</li>

				</ul>

			</div>

		</nav>

	)
}

export default Navbar

