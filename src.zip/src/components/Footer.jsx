function Footer() {

	return (

		<footer className="border-t border-gray-800 py-8 text-center text-gray-400">

			<div className="container-custom">
				© 2026 Abikumar Portfolio. All Rights Reserved.
			</div>

		</footer>

	)
}

export default Footer

